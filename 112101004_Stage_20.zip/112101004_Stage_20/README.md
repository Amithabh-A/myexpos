* For compilation and running : 
    ```
    cd xfs-interface
    ./c16
    ```
    Now, xfs-interface will be running. Run the following command: 
    ```
    run 16.txt
    ```
        
    Now for running the machine :
    ```
    cd ../xsm
    ./xsm
    ```                                                                                     

* For compilation and running of Assignment 1
    ```
    cd xfs-interface
    ./c16-a1
    ```
    ```
    run 16-a1.txt
    ```
    ```
    cd ../xsm
    ./xsm
    ```            
> Assignment 1 bubble sort is not correct. 
